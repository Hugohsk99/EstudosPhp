<?php
  require_once("library.php");

  // Your code goes here
?>

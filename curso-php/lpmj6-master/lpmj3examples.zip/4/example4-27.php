<?php
  $enough = $fuel <= 1 ? FALSE : TRUE;
?>

<?php
  mysql_select_db($db_database)
    or die("Unable to select database: " . mysql_error());
?>
<?php
  mysql_close($db_server);
?>